package aula9;

public class TransThread extends Thread {

    private Bank bank;
    private String name;
    private double amount;

    public TransThread(Bank bank, String name, double amount) {
        super(name);
        this.bank = bank;
        this.name = name;
        this.amount = amount;
    }

    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            bank.update(name, amount);
        }

    }
}

